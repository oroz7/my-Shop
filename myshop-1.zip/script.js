document.addEventListener('DOMContentLoaded', () => {
  alert('আমার শপে স্বাগতম!');
});